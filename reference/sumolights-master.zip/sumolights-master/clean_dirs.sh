#!/usr/bin/env bash
rm -rf metrics/*
rm -rf saved_models/*
rm -rf saved_replays/*
rm -rf hyperparams/*
rm -rf tmp/*
rm -rf hp/*
rm -rf figures/*
